/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String A;
        int B;
        System.out.println("Escriba su nombre");
         Scanner N1 = new Scanner(System.in);
        A = N1.nextLine();
    System.out.println("Escriba su edad");
    Scanner E1 = new Scanner(System.in);
    B = E1.nextInt();
   
    System.out.println("Su Nombre es " + A + " Y Su edad es " + B);
    }
    
}
